# BME280_light

Lightweight and minimal BME280 implementation.

This implementation is based on the work of reaper7 from ESP8266 board

Originally based on:
Adafruit Adafruit_BME280_Library https://github.com/adafruit/Adafruit_BME280_Library and Astuder BMP085-template-library-Energia https://github.com/astuder/BMP085-template-library-Energia plus code for altitude and relative pressure by r7

